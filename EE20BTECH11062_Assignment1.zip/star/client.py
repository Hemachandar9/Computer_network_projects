import socket

cacheIP = "10.0.1.2"



#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.
file_ = open('assignment1_req.txt','r')

for each_req in file_:
	#dst_ip = str(input("Enter dstIP: "))
	dst_ip = "10.0.1.2"
	
	s = socket.socket()
	
	print(dst_ip)
	
	port = 12346
	
	s.connect((dst_ip, port))
	#d = str(input("request : "))
	#d+='\n\n'
	d = each_req+'\n\n'
	s.send(d.encode())
	print ('Client received '+s.recv(1024).decode())
	s.close()
	if(each_req == 'exit'):
		break
file_.close()