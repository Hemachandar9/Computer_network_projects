import socket
import time

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).

Storage = {}

class Node:
    def __init__(self,data):
        self.value = data
        self.next = None
        self.prev = None

class Do_Linkl:
    size = 0
    max_size = 4
    def __init__(self):
        self.head = None
        self.tail = None

    def push(self,new_data):
        new_node = Node(data = new_data)
        new_node.next = self.head
        if self.head != None:
            self.head.prev = new_node
        self.head = new_node
        if self.tail == None:
            self.tail = new_node
        self.size = self.size + 1
        if(self.size>self.max_size):
            self.pop()
    
    def pop(self):
        if self.size == 0:
            return
        elif self.size == 1:
            self.head = None
            self.size = self.size-1
        else:
            pr = self.tail.prev
            self.tail = None
            self.tail = pr
            self.size = self.size-1
    
    def delete(self,node):
        pr = node.prev
        nx = node.next
        if pr == None:
            self.head = node.next
            node = None
            self.size = self.size-1
        elif nx == None:
            self.tail = node.prev
            self.tail.next = None
            self.size = self.size-1
        else:
            pr.next = nx
            nx.prev = pr
            self.size = self.size -1
    def print_(self):
        t = self.head
        while(t != None):
            print(t.value)
            t = t.next

d_l = Do_Linkl()



def GET(data):
	data = data.split('?')
	key = data[1].split('=')
	return key[1]

def PUT(data,ca_ser):
	data = data.split('/')
	
	d = 'PUT /assignment1/'+data[2]+'/'+data[3]+' HTTP/1.1\n\n'
	ca_ser.send(d.encode())
	recv_ser = ca_ser.recv(1024).decode()
	
	print ('Cache received '+recv_ser)
	return

def DELETE(data,ca_ser):
	data = data.split('/')
	if(data[2] in Storage):
		del Storage[data[2]]
		
	d = 'DELETE /assignment1/'+data[2]+' HTTP/1.1\n\n'
	ca_ser.send(d.encode())
	recv_ser = ca_ser.recv(1024).decode()
		
	print ('Cache received '+recv_ser)
	c.send(recv_ser.encode())

#dst_ip = str(input("Enter Server IP: "))
dst_ip = "10.0.1.2"

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

while True:
	dest_ip = "10.0.1.3"
	ca_ser = socket.socket()
	port = 12346
	ca_ser.connect((dest_ip, port))

	c, addr = s.accept()
	print ('Got connection from ', addr )
	data = c.recv(1024).decode()
	
	data = data.split(' ')
	if(data[0]=="exit\n\n"):
		#SAVE_file()
		#d = 'exit\n\n'
		ca_ser.send(data[0].encode())
		recv_ser = ca_ser.recv(1024).decode()
		ca_ser.close()
		#respo = 'HTTP/1.1 200 OK\n\n'
		c.send(recv_ser.encode())
		break
	elif(data[0]=="GET"):
		key_ = GET(data[1])
		if(key_ in Storage):
			d = 'GET /assignment1?time='+key_+' HTTP/1.1\n\n'
			ca_ser.send(d.encode())
			recv_ser = ca_ser.recv(1024).decode()
			recv_ser_ = recv_ser.split('\n\n')
			if(recv_ser_[0] == 'HTTP/1.1 200 OK'):
				time_ = recv_ser_[1]
				if(time_==Storage[key_][1]):
					recv_ser = recv_ser_[0]+'\n\n'+Storage[key_][0].value
					new_n = Node(val_)
					d_l.delete(Storage[key_][0])
					d_l.push(new_n)
					Storage[key_] = [new_n,time_]
				else:
					ca_ser.close()
					ca_ser = socket.socket()
					port = 12346
					ca_ser.connect((dest_ip, port))
					d = 'GET /assignment1?request='+key_+' HTTP/1.1\n\n'
					ca_ser.send(d.encode())
					recv_ser = ca_ser.recv(1024).decode()
					recv_ser_ = recv_ser.split('\n\n')
					if(recv_ser_[0] == 'HTTP/1.1 200 OK'):
						val_ = recv_ser[1]
						new_n = Node(val_)
						d_l.delete(Storage[key_][0])
						d_l.push(new_n)
						Storage[key_] = [new_n,time_]
						recv_ser = recv_ser_[0]+'\n\n'+val_
					else:
						recv_ser = recv_ser
			print ('Cache received '+recv_ser)
			
			#ca_ser.close()
			respo = recv_ser
			c.send(respo.encode())		
		else:
			d = 'GET /assignment1?request='+key_+' HTTP/1.1\n\n'
			ca_ser.send(d.encode())
			recv_ser = ca_ser.recv(1024).decode()
			recv_ser_ = recv_ser.split('\n\n')
			if(recv_ser_[0] == 'HTTP/1.1 200 OK'):
				val_ = recv_ser_[1]
				new_n = Node(val_)
				d_l.push(new_n)
				ca_ser.close()
				ca_ser = socket.socket()
				ca_ser.connect((dest_ip, port))
				d = 'GET /assignment1?time='+key_+' HTTP/1.1\n\n'
				ca_ser.send(d.encode())
				recv_sert = ca_ser.recv(1024).decode()
				recv_ser_t = recv_sert.split('\n\n')
				Storage[key_] = [new_n,recv_ser_t[1]]	
				recv_ser = recv_ser_[0]+'\n\n'+val_
				
			print ('Cache received '+recv_ser)
			c.send(recv_ser.encode())
	elif(data[0]=="PUT"):
		PUT(data[1],ca_ser)
		repo = 'HTTP/1.1 200 OK\n\n'+'Successfully_PUT_request'
		c.send(repo.encode())
	elif(data[0]=="DELETE"):
		DELETE(data[1],ca_ser)
	else:
		respo = 'HTTP/1.1 400 BAD REQUEST\n\n'
		c.send(respo.encode())

#	print('Server received '+recvmsg)
#	c.send('Hello client'.encode())
  
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################
	ca_ser.close()
	c.close()
	#break
