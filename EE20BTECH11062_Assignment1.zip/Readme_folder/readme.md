# CN-3530 COMPUTER NETWORK
### Assignment1 
Name : UGRANAM HEMA CHANDAR
Roll No.: EE20BTECH11062
## For Basic type Network

1.	Open a terminal and go to the ‘basic’ directory by using the below command.

```bash
cd tutorials/exercises/basic
```
2.	To open the mininet environment, run the below commands in the terminal.

```bash
make clean
make run
```
You will be seeing as below:
![jabf](1.png)

As the in the basic network, we have Node h1 and Node h2 referring to client and server respectively.
To run the Node h1 and Node h2 run the below commands:
```bash
xterm h1
xterm h2
```
You will be able to see to new Node terminals popping up as below:
![jabf](2.png)

4.	Firstly, open the server, so the below commands to open the server:
```bash
bash h2-arp.sh
python server.py
```
Then the server will be waiting for the client to connect.
![jabf](3.png)

5.	Then to connect the client run the below commands in Node h1 terminal:
```bash
bash h1-arp.sh
python client.py
```
After entering the IP address of the server “10.0.1.2” in the terminal you will be able to see the connection being made in the server as below.
![jabf](4.png)

6.	Now we are ready to make requests from client to server.
To PUT a key-value pair use the below command in the request:
```bash
“PUT /assignment1/k1/v1 HTTP/1.1” 
```
Where the key = k1 and value = v1. And you will be able to see the below received HTTP message in the client terminal.
![jabf](5.png)

Similarly, for the GET request use the below command in the client terminal.```bas
```bash
“GET /assignment1?request=k1 HTTP/1.1”
```
Where we request a value for the key = k1.
![jabf](6.png)

If we try to request a key which is not in server database then there would be an error as below:
![jabf](7.png)

Similarly, for the delete request use the below command.
```bash
“DELETE /assignment1/k1 HTTP/1.1”
```
Where it requests to delete the value with key = k1 in server.
![jabf](8.png)

If we try to delete a non-existing key then following error appears.
![jabf](9.png)

For the purpose of automation, I used a file named “assignment1_req.txt” for the requests to run one after the other which are written in the file.
Finally, use the “exit” command as a request in the client terminal to save the database in the server before exiting.

## For STAR Type Network:
It is almost same for the Star network.
1.	Open a terminal and go to the ‘star’ directory by using the below command.
```bash
cd tutorials/exercises/star
```
2.	To open the mininet environment, run the below commands in the terminal.
make 
You will be seeing as below:
![jabf](10.png)

As the in the basic network, we have Node h1, Node h2 and Node h3 referring to client, cache and server respectively.
To run the Node h1, Node h2 and Node h3 run the below commands:
```bash
xterm h1
xterm h2
xterm h3
```
3.	You will be able to see to new Node terminals popping up as below:

![jabf](11.png)

4.	Firstly, open the server, so the below commands to open the server:
```bash
bash h3-arp.sh
python server.py
```
Then the server will be waiting for the cache to connect.
![jabf](12.png)

5.	Then open the cache, so use the below command to open cache:
```bash
bash h2-arp.sh
python cache.py
```
After entering the IP address of the server “10.0.1.3” in the terminal you will be able to see the connection being made in the server as below.
Then the cache will connect to server and will be waiting for the client to connect.
![jabf](13.png)

6.	Then to connect the client run the below commands in Node h1 terminal:
```bash
bash h1-arp.sh
python client.py
```
After entering the IP address of the server “10.0.1.2” in the terminal you will be able to see the connection being made in the cache as below.
![jabf](14.png)

7.	Now we are ready to make requests from client to cache.
To PUT a key-value pair use the below command in the request:
```bash
“PUT /assignment1/k1/v1 HTTP/1.1”
```
Where the key = k1 and value = v1. And you will be able to see the below received HTTP message in the client terminal.
![jabf](15.png)

Similarly, for the GET request use the below command in the client terminal.
```bash
“GET /assignment1?request=k1 HTTP/1.1”
```
Where we request a value for the key = k1.
![jabf](16.png)

If we try to request a key which is not in cache and server database then there would be an error as below:
![jabf](17.png)

Similarly, for the delete request use the below command.
```bash
“DELETE /assignment1/k1 HTTP/1.1”
```
Where it requests to delete the value with key = k1 in server.
![jabf](18.png)

If we try to delete a non-existing key then following error appears.
![jabf](19.png)

For the purpose of automation, I used a file named “assignment1_req.txt” for the requests to run one after the other which are written in the file.
Finally, use the “exit” command as a request in the client terminal to save the database in the server before exiting.
