import socket

serverIP = "10.0.1.2"

#dst_ip = str(input("Enter dstIP: "))
dst_ip = "10.0.1.2"

file_ = open('assignment1_req.txt','r')

for each_line in file_:

	s = socket.socket()
	
	print(dst_ip)
	
	port = 12346
	
	s.connect((dst_ip, port))
	
	#Write your code here:
	#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
	#2. Add the code to parse the response you get from the server.
	
	#d = str(input("request : "))
	#d+='\n\n'
	d = each_line+'\n\n'
	s.send(d.encode())
	print ('Client received '+s.recv(1024).decode())
	
	s.close()
	if(each_line == 'exit'):
		break
file_.close()
