import socket
import time

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).

Storage = {}

file_ = open("assignment1.txt",'r')
for each_line in file_:
	each_line = each_line.strip()
	each_line = each_line.split(' ')
	#print(each_line)
	Storage[each_line[0]] = [each_line[1],str(each_line[2])]
file_.close()

def GET(data):
	data = data.split('?')
	key = data[1].split('=')
	return key[1]

def PUT(data):
	data = data.split('/')
	Storage[data[2]] = [data[3],str(time.time())]
	return

def DELETE(data):
	data = data.split('/')
	if(data[2] in Storage):
		del Storage[data[2]]
		respo = 'HTTP/1.1 200 OK\n\n'+'Successfully_deleted_key'
		c.send(respo.encode())
	else:
		respo = 'HTTP/1.1 404 NOT FOUND\n\n'+'No_such_key_exits'
		c.send(respo.encode())

def SAVE_file():
	file_ = open("assignment1.txt",'w')
	for k in Storage:
		file_.write(k+' '+Storage[k][0]+" "+Storage[k][1]+'\n')
	file_.close()

#dst_ip = str(input("Enter Server IP: "))
dst_ip = "10.0.1.2"

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

while True:
	c, addr = s.accept()
	print ('Got connection from', addr )
	data = c.recv(1024).decode()
	
	data = data.split(' ')
	if(data[0]=="exit\n\n"):
		SAVE_file()
		respo = 'HTTP/1.1 200 OK\n\n'
		c.send(respo.encode())
		break
	elif(data[0]=="GET"):
		key_ = GET(data[1])
		if(key_ in Storage):
			respo = 'HTTP/1.1 200 OK\n\n'+Storage[key_][0]
		else:
			respo = 'HTTP/1.1 404 NOT FOUND\n\n'+ 'Key not found'
		c.send(respo.encode())
	elif(data[0]=="PUT"):
		PUT(data[1])
		repo = 'HTTP/1.1 200 OK\n\n'+'Successfully_PUT_request'
		c.send(repo.encode())
	elif(data[0]=="DELETE"):
		DELETE(data[1])
	else:
		respo = 'HTTP/1.1 400 BAD REQUEST\n\n'
		c.send(respo.encode())

#	print('Server received '+recvmsg)
#	c.send('Hello client'.encode())
  
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################

	c.close()
	#break
