import socket
import struct
import time

def make_pkt(data, seq_num):
    packe = struct.pack('!H',seq_num)
    return packe+data

def send_pkt():
    global pkt_made_upto
    while pkt_made_upto < min(base_index+N,len(small_chunks)):
        snd_pkts[pkt_made_upto] = make_pkt(small_chunks[pkt_made_upto],pkt_made_upto)
        pkt_made_upto=pkt_made_upto+1

    
    for i in range(N):    
        if(base_index+i<len(small_chunks)):
            num_tra[base_index+i] += 1
            socket_udp.sendto(snd_pkts[base_index+i], recieverAddressPort)
            # print('send ',base_index+i)
        else:
            break

def send_pkt_one():
    global pkt_made_upto
    while pkt_made_upto < min(base_index+N,len(small_chunks)):
        snd_pkts[pkt_made_upto] = make_pkt(small_chunks[pkt_made_upto],pkt_made_upto)
        socket_udp.sendto(snd_pkts[pkt_made_upto], recieverAddressPort)
        num_tra[pkt_made_upto]+=1
        pkt_made_upto=pkt_made_upto+1

    
    # socket_udp.sendto(snd_pkts[base_index+N-1], recieverAddressPort)
    # print('send ',base_index+N-1)

def wait_ack():
    global base_index,num_retran
    recv_flag = False
    recv_msg = None
    i = 0
    j = N
    while ~recv_flag and i<j:
        try:
            recv_msg = socket_udp.recvfrom(bufferSize)
        except:
            # print("packet has been lost")
            # num_retran +=1
            send_pkt()
        if recv_msg!=None :
            num = struct.unpack('!H',recv_msg[0][:2])[0]
            if num>=base_index:
                base_index=num+1
                if base_index+N<len(small_chunks): 
                    send_pkt_one()
                    # wait_ack()
                    # break
                j+=1
                
                # break
            # else:
            #     while(True):
            #         try:
            #             recv_msg = socket_udp.recvfrom(bufferSize)
            #         except:
            #             break
            #     if(i==j-1 or base_index>=len(small_chunks)):
            #         recv_flag = True
            #         break
            #     send_pkt()
            #     # wait_ack()
            #     # break
        if(i==j-1 or base_index==len(small_chunks)):
            recv_flag = True
            break
        i+=1

def data2chunk(data,payload_size):
    small_chunks = [data[i:i+payload_size] for i in range(0, len(data), payload_size)]
    return small_chunks

senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 #Message Buffer Size

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
socket_udp.settimeout(0.025)

data = open('testFile.jpg','rb')
read_data = data.read()

size = 1022

small_chunks = data2chunk(read_data,size)
small_chunks.append(str.encode('exit'))
snd_pkts = small_chunks


base_index = 0
N = 256

pkt_made_upto = 0
seq_num = 0
num_retran = 0
total_time = 0
num_tra = [-1]*len(small_chunks)
through_put = 0

start_time = time.time()

while base_index<len(small_chunks):
    send_pkt()
    wait_ack()

end_time = time.time()

total_time += end_time-start_time

num_retran += sum(num_tra[:len(small_chunks)-1])
through_put += (1172316/1024)/(end_time-start_time)
print("window_size = ",N)

print("total_time = ",total_time,"s")
print("no. of retransmission = ",num_retran)

print("through_put = ",(1172316/1024)/(total_time),"KB/s\n")