import socket
import time
import struct

def send_ack(seq_num,client_Address):
    msg = struct.pack('!H',seq_num)+b'\x01'
    # print('ack ',seq_num)
    socket_udp.sendto(msg, client_Address)

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 #Message Buffer Size


# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))

print("UDP socket created successfully....." )

expec_seq_num = 0
curr_seq_num = 0

recv_bytes = bytearray()
total = 0

# start_time = time.time()
recv_image = open('recv_image.jpg','wb')

while True:

    #wait to recieve message from the server
    
    recv_from_sender = socket_udp.recvfrom(bufferSize)
    
    recv_msg = recv_from_sender[0]
    client_Address = recv_from_sender[1]

    curr_seq_num = struct.unpack('!H',recv_msg[:2])
    curr_seq_num = curr_seq_num[0]
    recv_msg = recv_msg[2:]

    if curr_seq_num==expec_seq_num:
        # print(expec_seq_num)
        send_ack(curr_seq_num,client_Address)
        expec_seq_num = expec_seq_num+1
        recv_image.write(recv_msg)
        total += 1
        
        if(recv_msg==b'exit'):
            break

        if(recv_bytes==bytearray()):
            recv_bytes = recv_msg
        else:
            recv_bytes = recv_bytes+recv_msg
    else:
        if(curr_seq_num>expec_seq_num):
            continue
        else:
            # print(curr_seq_num)
            send_ack(expec_seq_num-1,client_Address)
    
    

# print(total)
recv_image.close()

