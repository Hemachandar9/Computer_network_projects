Go to basic folder in terminal using the below command:
	"cd /home/p4/tutorials/exercises/basic"
Then, run the below command to open mininet:
	"sudo mn"
Then run the below commands:
	"xterm h1"
	"xterm h2"
In Node-1 terminal run the below commands:
	sudo tc qdisc add dev h1-eth0 root netem rate 10Mbit limit 100 delay 5ms loss 5%
In Node-2 terminal run the below commands:
	sudo tc qdisc add dev h2-eth0 root netem rate 10Mbit limit 100 delay 5ms loss 5%
Then run,
	In Node h1 - "python3 ee20btech11062_senderStopWait.py"
	In Node h1 - "python3 ee20btech11062_receiverStopWait.py"