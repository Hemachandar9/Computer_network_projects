import socket
import time

def make_pkt(data, seq_num):
    if seq_num==0: 
        return b'0'+data
    else: 
        return b'1'+data
    # return seq_num.to_bytes(1,'big')+data


def send_pkt(msg):
    # msg = str.encode(msg)
    socket_udp.sendto(msg, recieverAddressPort)
    num_retrans+=1

def wait_ack(msg):
    global num_retrans
    recv_flag = False
    recv_msg = None
    while ~recv_flag:
        try:
            recv_msg = socket_udp.recvfrom(bufferSize)
        except:
            # print("packet has been lost")
            # num_retrans+=1
            pass
        
        if recv_msg!=None and recv_msg[0][0]==msg[0]:
            # print(recv_msg[0][0]-48)
            recv_flag = True
            break
        else:
            send_pkt(msg)

def data2chunk(data,payload_size):
    small_chunks = [data[i:i+payload_size] for i in range(0, len(data), payload_size)]
    return small_chunks

senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 #Message Buffer Size

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

#data = input("enter the data: ")
data = open('testFile.jpg','rb')
read_data = data.read()

# temp = read_data.decode()

size = 1023

small_chunks = data2chunk(read_data,size)

small_chunks.append(str.encode('exit'))


seq_num = 0
num_retrans = 0
through_put = 0
total_time = 0
socket_udp.settimeout(0.01)

seq_num = 0

start_time = time.time()

for s_c in small_chunks:

    msg = make_pkt(s_c,seq_num)
    send_pkt(msg)
    wait_ack(msg)


    seq_num+=1
    seq_num%=2
end_time = time.time()

total_time += end_time-start_time
through_put += (1172316/1024)/(end_time-start_time)
print("retransmissions = ",num_retrans)
print("time = ",total_time," s")
print("through put = ",through_put,"KB/s")
# print("through_put/retransmissions = ",through_put/num_retrans,"\n")