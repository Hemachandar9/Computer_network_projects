import socket
import time

def send_ack(seq_num,client_Address):
    msg = seq_num.to_bytes(1,'big')+b'\x01'
    socket_udp.sendto(msg, client_Address)

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 #Message Buffer Size

# bytesToSend = str.encode(msgFromServer)

# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))
# socket_udp.settimeout(5)

print("UDP socket created successfully....." )

prev_seq_num = 0
curr_seq_num = 0

recv_bytes = bytes()

start_time = time.time()
recv_image = open('recv_image.jpg','wb')
recv_image.write(recv_bytes)

while True:
    recv_from_sender = socket_udp.recvfrom(bufferSize)

    recv_msg = recv_from_sender[0]
    client_Address = recv_from_sender[1]

    curr_seq_num = int(recv_msg[0])
    recv_msg = recv_msg[1:]

    if curr_seq_num==prev_seq_num:
        send_ack(curr_seq_num,client_Address)
        continue
    else:
        send_ack(curr_seq_num,client_Address)
        prev_seq_num = curr_seq_num
        if(recv_msg==b'exit'):
            break
        recv_image.write(recv_msg)
        # if(recv_bytes==bytes()):
        #     recv_bytes = recv_msg
        # else:
        #     recv_bytes = recv_bytes+recv_msg
    

recv_image.close()

